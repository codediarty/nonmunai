// 논문AI 가격표와 견적 계산 (브라우저·Apps Script 공용)
// Apps Script에 넣을 때는 빌드가 'export ' 키워드를 제거합니다. 최신 문법(?. ??)은 쓰지 않습니다.

export var DEFAULT_CATALOG = {
  version: '2026-11-26',
  currency: 'KRW',
  items: [
    // 논문: 유형별 4개 작업. unit = 추가 분량 과금 단위
    { code: 'P-MASTER-FULL', service: 'paper', type: 'master', task: 'full', name: '석사학위논문 80 Page 완성', price: 99000, baseUnits: 80, unitLabel: '쪽', unitSize: 10, unitPrice: 19000, days: 5, includes: ['연구 설계서(연구모형·가설·분석 계획)', '목차 확정본', '서론부터 결론까지 장별 본문 80 Page', '실존 참고문헌과 본문 인용(APA 7판)', '전공 분야 박사 최종 검수', '수정 1회'] },
    { code: 'P-MASTER-EDIT', service: 'paper', type: 'master', task: 'edit', name: '석사학위논문 첨삭·교정', price: 49000, baseUnits: 30, unitLabel: '쪽', unitSize: 10, unitPrice: 19000, days: 2, includes: ['원고 문장 교정(기준 30쪽)', '맞춤법·띄어쓰기·비문 바로잡기', '어색하고 긴 문장 다듬기', '용어·표기 통일', '수정 내역 표시본과 정리본'], excludes: ['AI 문체 고쳐 쓰기·인용 대조(심화 첨삭)', '내용 보완·구조 재구성(완성도 보완)'] },
    { code: 'P-MASTER-EDIT2', service: 'paper', type: 'master', task: 'edit', name: '석사학위논문 심화 첨삭', price: 200000, baseUnits: 100, unitLabel: '쪽', unitSize: 50, unitPrice: 100000, days: 4, includes: ['원고 심화 첨삭(기준 100쪽)', '기본 교정 전부(맞춤법·문장·용어 통일)', 'AI 문체·번역투를 자연스러운 학술 문장으로 고쳐 쓰기', '문단 흐름과 논리 연결 다듬기', '본문 인용과 참고문헌 목록 대조·형식 통일', '장별 보완 코멘트', '수정 내역 표시본과 정리본'], excludes: ['내용 보완 집필·구조 재구성(완성도 보완)'] },
    { code: 'P-MASTER-EDIT3', service: 'paper', type: 'master', task: 'edit', name: '석사학위논문 완성도 보완', price: 500000, baseUnits: 100, unitLabel: '쪽', unitSize: 20, unitPrice: 100000, days: 7, includes: ['원고 완성도 보완(기준 100쪽)', '심화 첨삭 전부(AI 문체·흐름·인용 대조)', '목차·장 구성 점검과 재배치', '부족한 근거·선행연구 보완 집필', '논리 비약과 사실·수치 확인', '참고문헌 실존 여부 확인', '수정 내역 표시본과 정리본', '수정 1회'] },
    { code: 'P-MASTER-FB', service: 'paper', type: 'master', task: 'feedback', name: '석사학위논문 교수님 피드백 반영·수정 보완·첨삭', price: 99000, days: 2, includes: ['교수님 피드백 전체 일괄 반영', '내용 수정·보완(근거, 분석, 논리 보강)', '수정한 원고의 문장·논리 첨삭', '수정표 포함(의견·수정 내용·쪽)', '반영 부분 파란색 표시본', '최종 정리본'] },
    { code: 'P-MASTER-PROP', service: 'paper', type: 'master', task: 'proposal', name: '석사학위논문 연구계획서 작성', price: 69000, baseUnits: 15, unitLabel: '쪽', unitSize: 5, unitPrice: 19000, days: 3, includes: ['연구 주제·제목 확정안', '연구 목적과 필요성', '이론적 배경 요약과 연구모형', '연구 방법·분석 계획', '참고문헌'] },
    { code: 'P-DOCTOR-FULL', service: 'paper', type: 'doctor', task: 'full', name: '박사학위논문 130 Page 완성', price: 199000, baseUnits: 130, unitLabel: '쪽', unitSize: 10, unitPrice: 29000, days: 10, includes: ['연구 설계서와 연구모형', '목차 확정본', '장별 본문 130 Page', '실존 참고문헌과 본문 인용(APA 7판)', '전공 분야 박사 최종 검수', '수정 1회'] },
    { code: 'P-DOCTOR-EDIT', service: 'paper', type: 'doctor', task: 'edit', name: '박사학위논문 첨삭·교정', price: 69000, baseUnits: 40, unitLabel: '쪽', unitSize: 10, unitPrice: 19000, days: 3, includes: ['원고 문장 교정(기준 40쪽)', '맞춤법·띄어쓰기·비문 바로잡기', '어색하고 긴 문장 다듬기', '용어·표기 통일', '수정 내역 표시본과 정리본'], excludes: ['AI 문체 고쳐 쓰기·인용 대조(심화 첨삭)', '내용 보완·구조 재구성(완성도 보완)'] },
    { code: 'P-DOCTOR-EDIT2', service: 'paper', type: 'doctor', task: 'edit', name: '박사학위논문 심화 첨삭', price: 300000, baseUnits: 150, unitLabel: '쪽', unitSize: 50, unitPrice: 100000, days: 6, includes: ['원고 심화 첨삭(기준 150쪽)', '기본 교정 전부(맞춤법·문장·용어 통일)', 'AI 문체·번역투를 자연스러운 학술 문장으로 고쳐 쓰기', '문단 흐름과 논리 연결 다듬기', '본문 인용과 참고문헌 목록 대조·형식 통일', '장별 보완 코멘트', '수정 내역 표시본과 정리본'], excludes: ['내용 보완 집필·구조 재구성(완성도 보완)'] },
    { code: 'P-DOCTOR-EDIT3', service: 'paper', type: 'doctor', task: 'edit', name: '박사학위논문 완성도 보완', price: 800000, baseUnits: 150, unitLabel: '쪽', unitSize: 20, unitPrice: 100000, days: 10, includes: ['원고 완성도 보완(기준 150쪽)', '심화 첨삭 전부(AI 문체·흐름·인용 대조)', '목차·장 구성 점검과 재배치', '부족한 근거·선행연구 보완 집필', '논리 비약과 사실·수치 확인', '참고문헌 실존 여부 확인', '수정 내역 표시본과 정리본', '수정 1회'] },
    { code: 'P-DOCTOR-FB', service: 'paper', type: 'doctor', task: 'feedback', name: '박사학위논문 교수님 피드백 반영·수정 보완·첨삭', price: 99000, days: 3, includes: ['교수님 피드백 전체 일괄 반영', '내용 수정·보완(근거, 분석, 논리 보강)', '수정한 원고의 문장·논리 첨삭', '수정표 포함(의견·수정 내용·쪽)', '반영 부분 파란색 표시본', '최종 정리본'] },
    { code: 'P-DOCTOR-PROP', service: 'paper', type: 'doctor', task: 'proposal', name: '박사학위논문 연구계획서 작성', price: 99000, baseUnits: 25, unitLabel: '쪽', unitSize: 5, unitPrice: 19000, days: 4, includes: ['연구 주제·제목 확정안', '연구 목적과 독창성', '이론적 배경과 연구모형', '연구 방법·분석 계획', '참고문헌'] },
    { code: 'P-JOURNAL-FULL', service: 'paper', type: 'journal', task: 'full', name: '학술지 투고논문 20 Page 완성', price: 99000, baseUnits: 20, unitLabel: '쪽', unitSize: 5, unitPrice: 19000, days: 4, includes: ['투고 학술지 형식 원고 20 Page', '국문·영문 초록', '실존 참고문헌과 본문 인용', '전공 분야 박사 최종 검수', '수정 1회'] },
    { code: 'P-JOURNAL-EDIT', service: 'paper', type: 'journal', task: 'edit', name: '학술지 투고논문 첨삭·교정', price: 39000, baseUnits: 20, unitLabel: '쪽', unitSize: 5, unitPrice: 9000, days: 2, includes: ['원고 문장 교정(기준 20쪽)', '맞춤법·띄어쓰기·비문 바로잡기', '어색하고 긴 문장 다듬기', '용어·표기 통일', '투고 규정 형식 점검', '수정 내역 표시본과 정리본'], excludes: ['AI 문체 고쳐 쓰기·인용 대조(심화 첨삭)', '내용 보완·구조 재구성(완성도 보완)'] },
    { code: 'P-JOURNAL-EDIT2', service: 'paper', type: 'journal', task: 'edit', name: '학술지 투고논문 심화 첨삭', price: 100000, baseUnits: 30, unitLabel: '쪽', unitSize: 30, unitPrice: 100000, days: 3, includes: ['원고 심화 첨삭(기준 30쪽)', '기본 교정 전부(맞춤법·문장·용어 통일)', 'AI 문체·번역투를 자연스러운 학술 문장으로 고쳐 쓰기', '문단 흐름과 논리 연결 다듬기', '본문 인용과 참고문헌 목록 대조·형식 통일', '장별 보완 코멘트', '수정 내역 표시본과 정리본'], excludes: ['내용 보완 집필·구조 재구성(완성도 보완)'] },
    { code: 'P-JOURNAL-EDIT3', service: 'paper', type: 'journal', task: 'edit', name: '학술지 투고논문 완성도 보완', price: 300000, baseUnits: 30, unitLabel: '쪽', unitSize: 10, unitPrice: 100000, days: 5, includes: ['원고 완성도 보완(기준 30쪽)', '심화 첨삭 전부(AI 문체·흐름·인용 대조)', '목차·장 구성 점검과 재배치', '부족한 근거·선행연구 보완 집필', '논리 비약과 사실·수치 확인', '참고문헌 실존 여부 확인', '수정 내역 표시본과 정리본', '수정 1회'] },
    { code: 'P-JOURNAL-FB', service: 'paper', type: 'journal', task: 'feedback', name: '학술지 심사 의견 반영(수정 보완)', price: 49000, days: 2, includes: ['심사 의견 전체 일괄 반영·수정', '심사 의견 답변서(Response letter) 작성', '반영 부분 파란색 표시본', '최종 정리본'] },
    { code: 'P-BACHELOR-FULL', service: 'paper', type: 'bachelor', task: 'full', name: '학사 졸업논문 30 Page 완성', price: 59000, baseUnits: 30, unitLabel: '쪽', unitSize: 10, unitPrice: 19000, days: 3, includes: ['주제·목차 구성', '장별 본문 30 Page', '실존 참고문헌과 본문 인용', '전공 분야 박사 최종 검수', '수정 1회'] },
    { code: 'P-BACHELOR-EDIT', service: 'paper', type: 'bachelor', task: 'edit', name: '학사·졸업논문 첨삭·교정', price: 29000, baseUnits: 20, unitLabel: '쪽', unitSize: 10, unitPrice: 9000, days: 2, includes: ['원고 문장 교정(기준 20쪽)', '맞춤법·띄어쓰기·비문 바로잡기', '어색하고 긴 문장 다듬기', '용어·표기 통일', '수정 내역 표시본과 정리본'], excludes: ['AI 문체 고쳐 쓰기·인용 대조(심화 첨삭)', '내용 보완·구조 재구성(완성도 보완)'] },
    { code: 'P-BACHELOR-EDIT2', service: 'paper', type: 'bachelor', task: 'edit', name: '학사·졸업논문 심화 첨삭', price: 100000, baseUnits: 40, unitLabel: '쪽', unitSize: 40, unitPrice: 100000, days: 3, includes: ['원고 심화 첨삭(기준 40쪽)', '기본 교정 전부(맞춤법·문장·용어 통일)', 'AI 문체·번역투를 자연스러운 학술 문장으로 고쳐 쓰기', '문단 흐름과 논리 연결 다듬기', '본문 인용과 참고문헌 목록 대조·형식 통일', '장별 보완 코멘트', '수정 내역 표시본과 정리본'], excludes: ['내용 보완 집필·구조 재구성(완성도 보완)'] },
    { code: 'P-BACHELOR-EDIT3', service: 'paper', type: 'bachelor', task: 'edit', name: '학사·졸업논문 완성도 보완', price: 300000, baseUnits: 30, unitLabel: '쪽', unitSize: 10, unitPrice: 100000, days: 5, includes: ['원고 완성도 보완(기준 30쪽)', '심화 첨삭 전부(AI 문체·흐름·인용 대조)', '목차·장 구성 점검과 재배치', '부족한 근거·선행연구 보완 집필', '논리 비약과 사실·수치 확인', '참고문헌 실존 여부 확인', '수정 내역 표시본과 정리본', '수정 1회'] },
    { code: 'P-BACHELOR-FB', service: 'paper', type: 'bachelor', task: 'feedback', name: '학사·졸업논문 교수님 피드백 반영·수정 보완·첨삭', price: 39000, days: 2, includes: ['교수님 피드백 전체 일괄 반영', '내용 수정·보완', '수정한 원고의 문장 첨삭', '수정표 포함', '반영 부분 파란색 표시본'] },
    { code: 'P-BACHELOR-PROP', service: 'paper', type: 'bachelor', task: 'proposal', name: '학사·졸업논문 연구계획서 작성', price: 29000, baseUnits: 8, unitLabel: '쪽', unitSize: 4, unitPrice: 9000, days: 2, includes: ['주제·제목 확정안', '연구 목적과 방법', '목차안', '참고문헌'] },
    { code: 'P-REPORT-FULL', service: 'paper', type: 'report', task: 'full', name: '일반 연구보고서 전체 구성·초고 완성', price: 59000, baseUnits: 20, unitLabel: '쪽', unitSize: 10, unitPrice: 19000, days: 3, includes: ['보고서 구성안', '본문 초고(기준 20쪽)', '참고자료 정리', '수정 1회'] },
    { code: 'P-REPORT-EDIT', service: 'paper', type: 'report', task: 'edit', name: '일반 연구보고서 첨삭·교정', price: 29000, baseUnits: 20, unitLabel: '쪽', unitSize: 10, unitPrice: 9000, days: 2, includes: ['원고 문장 교정(기준 20쪽)', '맞춤법·띄어쓰기·비문 바로잡기', '어색하고 긴 문장 다듬기', '용어·표기 통일', '수정 내역 표시본과 정리본'], excludes: ['AI 문체 고쳐 쓰기·인용 대조(심화 첨삭)', '내용 보완·구조 재구성(완성도 보완)'] },
    { code: 'P-REPORT-EDIT2', service: 'paper', type: 'report', task: 'edit', name: '일반 연구보고서 심화 첨삭', price: 100000, baseUnits: 40, unitLabel: '쪽', unitSize: 40, unitPrice: 100000, days: 3, includes: ['원고 심화 첨삭(기준 40쪽)', '기본 교정 전부(맞춤법·문장·용어 통일)', 'AI 문체·번역투를 자연스러운 학술 문장으로 고쳐 쓰기', '문단 흐름과 논리 연결 다듬기', '본문 인용과 참고문헌 목록 대조·형식 통일', '장별 보완 코멘트', '수정 내역 표시본과 정리본'], excludes: ['내용 보완 집필·구조 재구성(완성도 보완)'] },
    { code: 'P-REPORT-EDIT3', service: 'paper', type: 'report', task: 'edit', name: '일반 연구보고서 완성도 보완', price: 300000, baseUnits: 30, unitLabel: '쪽', unitSize: 10, unitPrice: 100000, days: 5, includes: ['원고 완성도 보완(기준 30쪽)', '심화 첨삭 전부(AI 문체·흐름·인용 대조)', '목차·장 구성 점검과 재배치', '부족한 근거·선행연구 보완 집필', '논리 비약과 사실·수치 확인', '참고문헌 실존 여부 확인', '수정 내역 표시본과 정리본', '수정 1회'] },
    { code: 'P-REPORT-FB', service: 'paper', type: 'report', task: 'feedback', name: '일반 연구보고서 검토 의견 반영', price: 29000, days: 2, includes: ['검토 의견 전체 일괄 반영', '수정표 포함', '반영 부분 파란색 표시본'] },
    { code: 'P-YOUTH-FULL', service: 'paper', type: 'youth', task: 'full', name: '청소년 탐구논문 구성·초고 완성', price: 39000, baseUnits: 10, unitLabel: '쪽', unitSize: 5, unitPrice: 9000, days: 2, includes: ['탐구 주제·질문 정리', '탐구 보고서 초고(기준 10쪽)', '참고자료 정리', '수정 1회'] },
    { code: 'P-YOUTH-EDIT', service: 'paper', type: 'youth', task: 'edit', name: '청소년 탐구논문 첨삭·교정', price: 19000, baseUnits: 10, unitLabel: '쪽', unitSize: 5, unitPrice: 9000, days: 1, includes: ['원고 문장 교정(기준 10쪽)', '맞춤법·띄어쓰기·비문 바로잡기', '어색하고 긴 문장 다듬기', '용어·표기 통일', '수정 내역 표시본과 정리본'], excludes: ['AI 문체 고쳐 쓰기·인용 대조(심화 첨삭)', '내용 보완·구조 재구성(완성도 보완)'] },
    { code: 'P-YOUTH-EDIT2', service: 'paper', type: 'youth', task: 'edit', name: '청소년 탐구논문 심화 첨삭', price: 100000, baseUnits: 30, unitLabel: '쪽', unitSize: 30, unitPrice: 100000, days: 2, includes: ['원고 심화 첨삭(기준 30쪽)', '기본 교정 전부(맞춤법·문장·용어 통일)', 'AI 문체·번역투를 자연스러운 학술 문장으로 고쳐 쓰기', '문단 흐름과 논리 연결 다듬기', '본문 인용과 참고문헌 목록 대조·형식 통일', '장별 보완 코멘트', '수정 내역 표시본과 정리본'], excludes: ['내용 보완 집필·구조 재구성(완성도 보완)'] },
    { code: 'P-YOUTH-EDIT3', service: 'paper', type: 'youth', task: 'edit', name: '청소년 탐구논문 완성도 보완', price: 200000, baseUnits: 20, unitLabel: '쪽', unitSize: 10, unitPrice: 100000, days: 4, includes: ['원고 완성도 보완(기준 20쪽)', '심화 첨삭 전부(AI 문체·흐름·인용 대조)', '목차·장 구성 점검과 재배치', '부족한 근거·선행연구 보완 집필', '논리 비약과 사실·수치 확인', '참고문헌 실존 여부 확인', '수정 내역 표시본과 정리본', '수정 1회'] },
    { code: 'P-YOUTH-FB', service: 'paper', type: 'youth', task: 'feedback', name: '청소년 탐구논문 선생님 피드백 반영', price: 19000, days: 1, includes: ['선생님 피드백 전체 일괄 반영', '수정표 포함', '반영 부분 파란색 표시본'] },
    { code: 'P-PERSONAL-FULL', service: 'paper', type: 'personal', task: 'full', name: '개인 관심연구 구성·초고 완성', price: 49000, baseUnits: 15, unitLabel: '쪽', unitSize: 5, unitPrice: 9000, days: 3, includes: ['연구 질문 정리', '연구 원고 초고(기준 15쪽)', '참고문헌 정리', '수정 1회'] },
    { code: 'P-PERSONAL-EDIT', service: 'paper', type: 'personal', task: 'edit', name: '개인 관심연구 첨삭·교정', price: 19000, baseUnits: 15, unitLabel: '쪽', unitSize: 5, unitPrice: 9000, days: 2, includes: ['원고 문장 교정(기준 15쪽)', '맞춤법·띄어쓰기·비문 바로잡기', '어색하고 긴 문장 다듬기', '용어·표기 통일', '수정 내역 표시본과 정리본'], excludes: ['AI 문체 고쳐 쓰기·인용 대조(심화 첨삭)', '내용 보완·구조 재구성(완성도 보완)'] },
    { code: 'P-PERSONAL-EDIT2', service: 'paper', type: 'personal', task: 'edit', name: '개인 관심연구 심화 첨삭', price: 100000, baseUnits: 30, unitLabel: '쪽', unitSize: 30, unitPrice: 100000, days: 3, includes: ['원고 심화 첨삭(기준 30쪽)', '기본 교정 전부(맞춤법·문장·용어 통일)', 'AI 문체·번역투를 자연스러운 학술 문장으로 고쳐 쓰기', '문단 흐름과 논리 연결 다듬기', '본문 인용과 참고문헌 목록 대조·형식 통일', '장별 보완 코멘트', '수정 내역 표시본과 정리본'], excludes: ['내용 보완 집필·구조 재구성(완성도 보완)'] },
    { code: 'P-PERSONAL-EDIT3', service: 'paper', type: 'personal', task: 'edit', name: '개인 관심연구 완성도 보완', price: 200000, baseUnits: 20, unitLabel: '쪽', unitSize: 10, unitPrice: 100000, days: 4, includes: ['원고 완성도 보완(기준 20쪽)', '심화 첨삭 전부(AI 문체·흐름·인용 대조)', '목차·장 구성 점검과 재배치', '부족한 근거·선행연구 보완 집필', '논리 비약과 사실·수치 확인', '참고문헌 실존 여부 확인', '수정 내역 표시본과 정리본', '수정 1회'] },
    { code: 'P-SHORT-FULL', service: 'paper', type: 'short', task: 'full', name: '소논문 15 Page 완성', price: 49000, baseUnits: 15, unitLabel: '쪽', unitSize: 5, unitPrice: 9000, days: 2, includes: ['주제와 연구 질문 정리', '소논문 본문 15 Page', '실존 참고문헌과 본문 인용', '전공 분야 박사 최종 검수', '수정 1회'] },
    { code: 'P-PERSONAL-FB', service: 'paper', type: 'personal', task: 'feedback', name: '개인 관심연구 피드백 반영', price: 19000, days: 2, includes: ['피드백 전체 일괄 반영', '수정표 포함', '반영 부분 파란색 표시본'] },
    // 설문조사
    { code: 'S-FULL', service: 'survey', task: 'full', name: '설문조사 원스톱: 설문지 작성부터 설문 결과·통계 해석까지', price: 149000, days: 4, includes: ['연구 목적에 맞는 설문지 작성(검증된 척도)', '온라인 설문 제작과 설문조사 진행 관리', '설문 결과 정리(문항별 응답 결과 표·그래프)', '응답 데이터 정리·익명화', '논문 맞춤 통계 분석과 결과 해석', '연구결과 정리'], excludes: ['응답자 모집·사례비(모집 의뢰 시 별도 견적)'] },
    { code: 'S-NEW', service: 'survey', task: 'new', name: '설문지 작성', price: 39000, days: 2, includes: ['연구 변인별 검증된 척도 선정과 문항 구성', '인구통계 문항 구성', '설문지 파일(Word)', '배포용 온라인 설문 링크'] },
    { code: 'S-EDIT', service: 'survey', task: 'edit', name: '설문지 점검·수정', price: 29000, days: 1, includes: ['문항 구성·표현 점검과 수정', '척도 구성 점검', '수정본과 수정 내역'] },
    { code: 'S-FB', service: 'survey', task: 'feedback', name: '설문지 교수님 피드백 반영', price: 29000, days: 1, includes: ['설문지 피드백 전체 일괄 반영', '수정표 포함', '반영 부분 파란색 표시본'] },
    { code: 'S-ANALYZE', service: 'survey', task: 'analyze', name: '설문 응답 통계 분석·해석', price: 69000, days: 3, includes: ['응답 데이터 정리·결측 점검', '연구 가설에 맞는 분석(신뢰도·기술통계·가설 검증)', 'APA 형식 통계표와 결과 해석'] },
    { code: 'S-RECRUIT', service: 'survey', task: 'recruit', name: '응답자 모집·배포 대행', price: 0, quoteOnly: true, days: 0, includes: ['모집 경로·일정·표본 계획 수립', '참여 동의 절차와 개인정보 보호 안내', '모집 진행 현황 공유'], excludes: ['IRB 심의 비용'] },
    // 통계분석
    { code: 'T-BASIC', service: 'statistics', task: 'table', name: '논문 맞춤 통계분석 기본형', price: 49000, days: 2, includes: ['데이터 점검·정리', '주제와 데이터에 맞는 분석 실행', 'APA 형식 통계표', '핵심 결과 해석'] },
    { code: 'T-INTERP', service: 'statistics', task: 'interp', name: '논문 맞춤 통계분석 표준형', price: 69000, days: 3, includes: ['연구 주제·가설에 맞는 분석 설계', '데이터 점검·정리', '분석 실행(SPSS·PROCESS 등)', 'APA 형식 통계표', '표별 결과 해석과 설명'] },
    { code: 'T-CHAPTER', service: 'statistics', task: 'chapter', name: '논문 맞춤 통계분석과 연구결과 작성', price: 99000, days: 4, includes: ['표준형 분석 전체(분석 설계·통계표·해석)', '연구결과(4장) 본문 작성', '표·그림 번호 정리'] },
    { code: 'T-FB', service: 'statistics', task: 'revise', name: '통계 재분석·교수님 피드백 반영', price: 39000, days: 2, includes: ['피드백 전체 일괄 재분석·수정', '수정된 통계표', '수정표 포함', '반영 부분 파란색 표시'] },
    { code: 'T-SIM', service: 'statistics', task: 'simulation', name: '학습용 시뮬레이션 데이터 분석', price: 19000, days: 2, includes: ['교육용 가상 데이터 생성', '분석 절차 실습 결과와 해설'], excludes: ['실제 연구 결과로 사용 불가(가상 데이터 표시)'] },
    { code: 'T-ADV', service: 'statistics', task: 'advanced', name: '심화 분석(매개·조절효과)', price: 19000, days: 1, addon: true, includes: ['PROCESS Macro 매개·조절효과 분석'] },
    // 공통 추가 옵션: 심사 발표 PPT, 영문 논문 작성(10쪽 단위)이 앞, 일정·형식 옵션이 뒤
    { code: 'A-PPT', service: 'addon', name: '심사 발표 PPT·PDF 제작', price: 49000, days: 1, addon: true, includes: ['논문 핵심을 담은 발표 자료(15~20장)', 'PPT 원본과 PDF 파일 함께 제공', '장표별 발표 스크립트', '표·그림을 살린 학술 발표 디자인'] },
    { code: 'A-ENGLISH', service: 'addon', name: '영문 논문 작성(10 Page 단위)', price: 29000, baseUnits: 0, unitLabel: '쪽', unitSize: 10, unitPrice: 29000, days: 3, addon: true, includes: ['학술 영어로 원고 작성', '영문 초록과 주제어', '영문 참고문헌 형식 정리'] },
    { code: 'A-PRIORITY', service: 'addon', name: '우선 처리', price: 29000, addon: true, includes: ['작업 순서를 앞당겨 납기 단축(가능한 경우에만 선택 가능)'] },
    { code: 'A-FORMAT', service: 'addon', name: '학교·학술지 양식 상세 적용', price: 19000, addon: true, includes: ['제출 양식(여백·글꼴·표·그림·목차 서식) 상세 적용'] },
    { code: 'A-REVISION', service: 'addon', name: '추가 수정 1회', price: 19000, addon: true, includes: ['전달 후 수정 요청 1회 추가'] },
  ],
  settings: {
    priorityEnabled: true,
    vatIncluded: true,
    payInFullDiscountRate: 0,
  },
};

// 정가: 할인 행사 가격과 함께 보여 주는 기준 가격(표시용, 결제 금액 계산에는 쓰지 않음)
export var LIST_PRICE = {
  'P-SHORT-FULL': 109000, 'P-BACHELOR-FULL': 139000, 'P-JOURNAL-FULL': 229000, 'P-MASTER-FULL': 249000, 'P-DOCTOR-FULL': 459000,
  'P-BACHELOR-PROP': 69000, 'P-MASTER-PROP': 159000, 'P-DOCTOR-PROP': 229000,
};
export function listPriceFor(code, price) {
  var l = LIST_PRICE[code];
  return l && l > (Number(price) || 0) ? l : 0;
}
export function discountRate(list, price) {
  if (!list || !price || list <= price) return 0;
  return Math.floor((1 - price / list) * 100);
}
// 할인 이름과 할인 표시: 할인율을 그대로 '60%'처럼(정가의 정확히 절반일 때만 '반값')
export var PROMO_NAME = '온라인 단독가';
export var PROMO_SHORT = '온라인 단독';
export function offText(list, price, opts) {
  var r = discountRate(list, price);
  if (!r) return '';
  if (r === 50 || r === 51) return '반값';
  return opts && opts.short ? r + '%' : r + '% 할인';
}
// 할인 이름(기간 없이 계속 쓰는 이름): '온라인 단독 60% 할인'(정확히 반값일 때만 '온라인 단독가')
export function promoText(list, price) {
  var o = offText(list, price);
  return !o ? '' : o === '반값' ? PROMO_NAME : PROMO_SHORT + ' ' + o;
}
// 분량 표기: 80 Page
export function pageLabel(n) { return n ? n + ' Page' : ''; }

export var TASK_LABELS = { full: '논문 완성(전체 구성·본문)', edit: '논문 첨삭·교정', feedback: '교수님 피드백 반영', proposal: '연구계획서 작성' };

// 논문 첨삭 추가 옵션이 쓸 수 있는 논문 유형
export var EDIT_TYPES = ['master', 'doctor', 'journal', 'bachelor', 'report', 'youth', 'personal'];

export function findItem(catalog, code) {
  var items = (catalog && catalog.items) || [];
  for (var i = 0; i < items.length; i++) if (items[i].code === code && items[i].active !== false) return items[i];
  return null;
}

// 논문 첨삭 단계(2026-11-26): 같은 '원고 첨삭'도 손보는 범위에 따라 세 단계로 나눈다.
// 기본 교정은 기존 상품(P-유형-EDIT), 심화 첨삭(EDIT2)·완성도 보완(EDIT3)은 10만 원 단위 금액이라
// 아임웹 '맞춤 견적 결제'(10만~100만 원) 상품 하나로 바로 결제된다.
export var EDIT_LEVELS = [
  { id: 'basic', suffix: '', label: '기본 교정', short: '문장 교정', pitch: '내용과 흐름은 그대로 두고 문장만 다듬어요', limit: '문장만 다듬고 흐름·인용·내용은 손대지 않아요', points: ['맞춤법·띄어쓰기·비문 교정', '어색하고 긴 문장 다듬기', '용어·표기 통일'] },
  { id: 'deep', suffix: '2', label: '심화 첨삭', short: 'AI 문체·흐름·인용', pitch: '읽히는 원고로 고쳐 쓰고 인용까지 맞춰요', limit: '문장·흐름·인용은 다듬지만 내용을 보태 쓰거나 구성을 바꾸지는 않아요', points: ['기본 교정 전부', 'AI 문체·번역투 자연스럽게 고쳐 쓰기', '문단 흐름과 논리 연결 다듬기', '본문 인용과 참고문헌 대조', '장별 보완 코멘트'] },
  { id: 'complete', suffix: '3', label: '완성도 보완', short: '구조·내용 보완까지', pitch: '제출할 수 있는 원고로 끝까지 채워요', limit: '', points: ['심화 첨삭 전부', '목차·장 구성 점검과 재배치', '부족한 근거·선행연구 보완 집필', '논리 비약과 사실·수치 확인', '참고문헌 실존 확인, 수정 1회'] },
];
export function editLevelOf(id) {
  for (var i = 0; i < EDIT_LEVELS.length; i++) if (EDIT_LEVELS[i].id === id) return EDIT_LEVELS[i];
  return EDIT_LEVELS[0];
}
// 상품 코드로 첨삭 단계 알기(가격표 시트에는 단계 칸이 없어서 코드 끝 숫자로 구분)
export function editLevelOfCode(code) {
  var m = /-EDIT([23])?$/.exec(String(code || ''));
  if (!m) return null;
  return m[1] === '3' ? EDIT_LEVELS[2] : m[1] === '2' ? EDIT_LEVELS[1] : EDIT_LEVELS[0];
}

export function paperItemCode(typeId, task, level) {
  var code = 'P-' + String(typeId || 'master').toUpperCase() + '-' + ({ full: 'FULL', edit: 'EDIT', feedback: 'FB', proposal: 'PROP' }[task] || 'FULL');
  return task === 'edit' && level ? code + editLevelOf(level).suffix : code;
}

// 맞춤 견적 결제 금액(아임웹 상품): 10만 원부터 100만 원까지 10만 원 단위
export var QUOTE_STEP = 100000;
export var QUOTE_MAX = 1000000;
export var QUOTE_AMOUNTS = [100000, 200000, 300000, 400000, 500000, 600000, 700000, 800000, 900000, 1000000];
export function isQuoteAmount(n) { n = Number(n) || 0; return n >= QUOTE_STEP && n <= QUOTE_MAX && n % QUOTE_STEP === 0; }

// 포함 항목의 분량 표기를 실제 주문 분량으로 바꾸고, 'N쪽'은 'N Page'로 보여 준다
export function includesFor(list, pages) {
  const n = Number(pages) || 0;
  return (list || []).map((x) => {
    let t = String(x);
    if (n > 0) t = t.replace(/\(기준\s*\d+\s*쪽(\s*내외)?\)/, `(${n} Page)`).replace(/(본문|원고)\s+\d+\s*Page/, `$1 ${n} Page`);
    // 운영 가격표에 예전 문구(전문가 최종 검토·전공 분야 전문가 최종 검수)가 남아 있어도 화면에는 새 표현으로(전공 분야 박사 최종 검수)
    return t.replace(/(\d+)\s*쪽/g, '$1 Page').replace(/(?:석·박사\s*)?전문가\s*최종\s*검토|전공\s*분야\s*전문가\s*최종\s*검수/, '전공 분야 박사 최종 검수');
  });
}

export function won(n) {
  return (Math.round(Number(n) || 0)).toLocaleString('ko-KR') + '원';
}

function isMetered(it) { return !!it && it.baseUnits != null && it.baseUnits !== '' && Number(it.unitSize) > 0; }
// 기준 분량을 넘는 만큼 늘어나는 납기: 추가 2단위마다 하루, 최대 5일
function extraDays(it, units) {
  if (!isMetered(it) || units == null || !(units > it.baseUnits)) return 0;
  return Math.min(5, Math.ceil(Math.ceil((units - it.baseUnits) / it.unitSize) / 2));
}

function line(item, opts) {
  opts = opts || {};
  var qty = opts.qty || 1;
  var unit = opts.unitPrice != null ? opts.unitPrice : item.price;
  return { code: item.code, name: opts.name || item.name, qty: qty, unitPrice: unit, amount: unit * qty, note: opts.note || '' };
}

// 주문 입력(정규화된 형태)으로 견적 계산
export function computeQuote(catalog, input) {
  catalog = catalog || DEFAULT_CATALOG;
  input = input || {};
  var lines = [];
  var reasons = [];
  var notes = [];
  var includes = [];
  var excludes = [];
  var days = 0;
  var main = null;
  var service = input.service;

  if (service === 'paper') {
    var p = input.paper || {};
    var level = p.task === 'edit' && p.editLevel && p.editLevel !== 'basic' ? p.editLevel : '';
    main = findItem(catalog, paperItemCode(p.typeId, p.task, level));
    // 고른 첨삭 단계가 가격표에 없으면 기본 교정 금액으로 결제받지 않고 확인 후 금액을 안내한다
    if (!main && level) {
      main = findItem(catalog, paperItemCode(p.typeId, 'edit'));
      reasons.push('선택하신 첨삭 단계(' + editLevelOf(level).label + ')는 원고를 확인한 뒤 금액을 안내드립니다.');
    }
    if (!main) main = findItem(catalog, paperItemCode(p.typeId, 'full'));
    if (main) {
      lines.push(line(main));
      days = main.days || 0;
      includes = (main.includes || []).slice();
      excludes = (main.excludes || []).slice();
      // 추가 분량
      var units = null;
      var metered = isMetered(main);
      if (main.unitLabel === '항목') units = p.feedbackItems != null ? Number(p.feedbackItems) : null;
      else units = p.pages != null && p.pages !== '' ? Number(p.pages) : null;
      if (metered && units != null && units > main.baseUnits) {
        var extraBlocks = Math.ceil((units - main.baseUnits) / main.unitSize);
        lines.push({ code: main.code + '-X', name: '추가 분량 (' + main.unitSize + main.unitLabel + ' 단위 × ' + extraBlocks + ')', qty: extraBlocks, unitPrice: main.unitPrice, amount: main.unitPrice * extraBlocks, note: '기준 ' + main.baseUnits + main.unitLabel + ' 초과 ' + (units - main.baseUnits) + main.unitLabel });
        days += extraDays(main, units);
      }
      // 심화·완성도 보완 납기: 같은 분량의 기본 교정 납기보다 단계만큼 길게(단계 상품은 분량 단위가 커서 따로 계산하면 짧아질 수 있음)
      var basicEdit = level ? findItem(catalog, paperItemCode(p.typeId, 'edit')) : null;
      if (basicEdit && basicEdit.code !== main.code) days = Math.max(days, (basicEdit.days || 0) + extraDays(basicEdit, units) + Math.max(0, (main.days || 0) - (basicEdit.days || 0)));
      if (metered && units == null) notes.push('분량을 모르셔도 기준 분량(' + main.baseUnits + main.unitLabel + ')으로 먼저 진행하고, 자료 확인 후 초과분이 있을 때만 추가 결제를 안내드립니다.');
      if (p.needsData) notes.push('결과 장은 실제 데이터 분석 후 작성됩니다. 데이터가 없으면 설문조사·통계분석 서비스와 연결해 드립니다.');
    }
  } else if (service === 'survey') {
    var s = input.survey || {};
    main = findItem(catalog, { full: 'S-FULL', new: 'S-NEW', edit: 'S-EDIT', feedback: 'S-FB', analyze: 'S-ANALYZE' }[s.mode] || 'S-FULL');
    if (main) { lines.push(line(main)); days = main.days || 0; includes = (main.includes || []).slice(); excludes = (main.excludes || []).slice(); }
    if (s.recruit === 'us') {
      reasons.push('응답자 모집·배포는 대상, 응답 수, 모집 경로, 기간에 따라 비용이 달라 확정 견적 후 결제합니다.');
      var r = findItem(catalog, 'S-RECRUIT');
      if (r) { lines.push({ code: r.code, name: r.name, qty: 1, unitPrice: 0, amount: 0, note: '견적 확정 후 안내', pending: true }); includes = includes.concat(r.includes || []); }
    }
    if (s.mode === 'analyze' && s.advanced) {
      var adv = findItem(catalog, 'T-ADV');
      if (adv) lines.push(line(adv));
    }
    if (s.sem) reasons.push('구조방정식 분석은 모형 복잡도에 따라 별도 견적입니다.');
  } else if (service === 'statistics') {
    var t = input.statistics || {};
    if (t.hasData === false && t.noDataPath === 'survey') {
      main = findItem(catalog, 'S-FULL');
      if (main) { lines.push(line(main)); days = main.days || 0; includes = (main.includes || []).slice(); excludes = (main.excludes || []).slice(); }
      reasons.push('실제 응답 조사부터 진행하는 경우 모집 비용을 포함한 통합 견적을 드립니다.');
    } else if (t.hasData === false) {
      main = findItem(catalog, 'T-SIM');
      if (main) { lines.push(line(main)); days = main.days || 0; includes = (main.includes || []).slice(); excludes = (main.excludes || []).slice(); }
    } else {
      main = findItem(catalog, { table: 'T-BASIC', interp: 'T-INTERP', chapter: 'T-CHAPTER', revise: 'T-FB' }[t.output] || 'T-INTERP');
      if (main) { lines.push(line(main)); days = main.days || 0; includes = (main.includes || []).slice(); }
      if (t.advanced && t.output !== 'revise') {
        var adv2 = findItem(catalog, 'T-ADV');
        if (adv2) { lines.push(line(adv2)); days += adv2.days || 0; }
      }
      if (t.sem) reasons.push('구조방정식·다층모형 등 심화 분석은 모형과 데이터 구조를 확인한 뒤 견적을 확정합니다.');
      if (t.messy) reasons.push('여러 파일 병합·대규모 정리 등 복잡한 데이터 정리는 분량 확인 후 견적을 확정합니다.');
    }
  }

  // 공통 추가 옵션
  var a = input.addons || {};
  var settings = catalog.settings || {};
  if (a.priority && settings.priorityEnabled !== false) {
    var pr = findItem(catalog, 'A-PRIORITY');
    if (pr) { lines.push(line(pr)); days = Math.max(1, Math.ceil(days / 2)); }
  }
  if (a.format && service === 'paper') {
    var fm = findItem(catalog, 'A-FORMAT');
    if (fm) lines.push(line(fm));
  }
  if (a.revisions && Number(a.revisions) > 0) {
    var rv = findItem(catalog, 'A-REVISION');
    if (rv) lines.push(line(rv, { qty: Math.min(5, Number(a.revisions)) }));
  }
  // 심사 발표 PPT: 모든 서비스
  if (a.ppt && main) {
    var ppt = findItem(catalog, 'A-PPT');
    if (ppt) { lines.push(line(ppt)); days += ppt.days || 0; includes = includes.concat(ppt.includes || []); }
  }
  // 영문 논문 작성: 전체 구성·초고 완성에만, 원고 분량 10쪽마다 1단위
  if (a.english && service === 'paper' && main && main.task === 'full') {
    var en = findItem(catalog, 'A-ENGLISH');
    if (en) {
      var enSize = Number(en.unitSize) || 10;
      var enPages = Math.max(Number(main.baseUnits) || 0, Number((input.paper || {}).pages) || 0);
      var enBlocks = Math.max(1, Math.ceil(enPages / enSize));
      var enUnit = Number(en.unitPrice) || Number(en.price) || 0;
      lines.push(line(en, { qty: enBlocks, unitPrice: enUnit, name: '영문 논문 작성 (' + enSize + ' Page 단위 × ' + enBlocks + ')' }));
      days += en.days || 0;
      includes = includes.concat(en.includes || []);
    }
  }
  // 논문 첨삭·교정 추가: 직접 쓴 원고가 있는 주문(통계·설문, 피드백 반영)에 그 유형의 첨삭 상품을 더한다
  if (a.editing && main && (service === 'statistics' || service === 'survey' || (service === 'paper' && main.task === 'feedback'))) {
    var edType = service === 'paper' ? main.type : (EDIT_TYPES.indexOf(a.editingType) >= 0 ? a.editingType : 'master');
    var ed = findItem(catalog, paperItemCode(edType, 'edit'));
    if (ed) {
      lines.push(line(ed, { name: ed.name + ' (추가)', note: '기준 ' + ed.baseUnits + ed.unitLabel }));
      days += 1;
      includes = includes.concat(['논문 원고 문장 교정(기본 교정, 기준 ' + ed.baseUnits + ed.unitLabel + ')']);
      notes.push('논문 기본 교정은 기준 ' + ed.baseUnits + ed.unitLabel + '으로 계산했습니다. 원고가 더 길면 확인한 뒤 추가 금액을 안내드립니다.');
    }
  }

  var total = 0;
  for (var i = 0; i < lines.length; i++) total += lines[i].amount;
  var quoteRequired = reasons.length > 0 || (main && main.quoteOnly) || !main;
  if (!main) reasons.push('선택하신 조건에 맞는 상품을 찾지 못해 견적 확인이 필요합니다.');
  return {
    catalogVersion: catalog.version,
    lines: lines,
    total: total,
    quoteRequired: !!quoteRequired,
    quoteReasons: reasons,
    payableNow: !quoteRequired && total > 0,
    days: days,
    includes: includes,
    excludes: excludes,
    notes: notes,
    mainCode: main ? main.code : null,
    mainName: main ? main.name : '',
  };
}

// 영업일 계산 (주말·지정 휴일 제외)
export function addBusinessDays(start, n, holidays) {
  var d = new Date(start.getTime());
  var hs = holidays || [];
  var added = 0;
  var guard = 0;
  while (added < n && guard < 400) {
    d.setDate(d.getDate() + 1);
    guard++;
    var dow = d.getDay();
    var key = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    if (dow === 0 || dow === 6 || hs.indexOf(key) >= 0) continue;
    added++;
  }
  return d;
}

export function etaDate(fromDate, days, holidays) {
  return addBusinessDays(fromDate, Math.max(1, days || 1), holidays);
}
