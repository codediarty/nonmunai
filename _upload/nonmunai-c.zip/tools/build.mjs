// 논문AI 정적 사이트 빌드: node tools/build.mjs
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import crypto from 'node:crypto';
import * as esbuild from 'esbuild';
import { createTemplates } from '../src/templates/layout.mjs';
import { loadGuides } from './guides.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.resolve(root, process.env.OUT_DIR || 'docs');
const site = JSON.parse(fs.readFileSync(path.join(root, 'site.config.json'), 'utf8'));
// Pages가 도메인 연결 직후 http 주소를 알려 주더라도 대표 주소는 항상 https로 쓴다
if (process.env.SITE_URL) site.siteUrl = process.env.SITE_URL.replace(/^http:\/\/(?!localhost|127\.0\.0\.1)/, 'https://').replace(/\/+$/, '');
if (process.env.API_URL !== undefined) site.apiUrl = process.env.API_URL;
if (process.env.BASE_PATH !== undefined) site.basePath = process.env.BASE_PATH;
const assetVersion = process.env.ASSET_VERSION || crypto.createHash('md5').update(String(Date.now())).digest('hex').slice(0, 8);

const T = createTemplates({ site, root, assetVersion });
const write = (rel, content) => {
  const file = path.join(out, rel);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, content);
};
const copyDir = (from, to, filter = () => true) => {
  fs.mkdirSync(to, { recursive: true });
  for (const f of fs.readdirSync(from)) {
    const s = path.join(from, f);
    if (fs.statSync(s).isDirectory()) copyDir(s, path.join(to, f), filter);
    else if (filter(f)) fs.copyFileSync(s, path.join(to, f));
  }
};

// 0) 출력 폴더 정리 (CNAME 유지)
const keep = ['CNAME'];
if (fs.existsSync(out)) {
  for (const f of fs.readdirSync(out)) if (!keep.includes(f)) fs.rmSync(path.join(out, f), { recursive: true, force: true });
} else fs.mkdirSync(out, { recursive: true });

// 1) 글꼴
const fontsOut = path.join(out, 'assets/fonts');
copyDir(path.join(root, 'node_modules/pretendard/dist/web/variable/woff2-dynamic-subset'), path.join(fontsOut, 'pretendard'));
const serifFiles = path.join(root, 'node_modules/@fontsource/noto-serif-kr/files');
copyDir(serifFiles, path.join(fontsOut, 'noto-serif-kr'), (f) => /-(400|700)-normal\.woff2$/.test(f));
fs.copyFileSync(path.join(root, 'node_modules/@fontsource/source-serif-4/files/source-serif-4-latin-400-italic.woff2'), path.join(fontsOut, 'source-serif-4-italic.woff2'));
const pretendardCss = fs.readFileSync(path.join(root, 'node_modules/pretendard/dist/web/variable/pretendardvariable-dynamic-subset.css'), 'utf8')
  .replace(/\/\*[\s\S]*?\*\//g, '').replace(/url\(\.\/woff2-dynamic-subset\//g, `url(${site.basePath}/assets/fonts/pretendard/`);
const serifCss = ['400', '700'].map((w) => fs.readFileSync(path.join(root, `node_modules/@fontsource/noto-serif-kr/${w}.css`), 'utf8'))
  .join('\n').replace(/\/\*[\s\S]*?\*\//g, '')
  .replace(/src: url\(\.\/files\/([^)]+\.woff2)\) format\('woff2'\), url\([^)]+\) format\('woff'\);/g, `src: url(${site.basePath}/assets/fonts/noto-serif-kr/$1) format('woff2');`);
const statCss = `@font-face{font-family:'Source Serif 4';font-style:italic;font-display:swap;font-weight:400;src:url(${site.basePath}/assets/fonts/source-serif-4-italic.woff2) format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD,U+03B1-03C9}`;
const fontsCss = pretendardCss + serifCss + statCss;

// 2) CSS 묶기
const css = (names, withFonts = true) => (withFonts ? fontsCss : '') + names.map((n) => fs.readFileSync(path.join(root, `src/styles/${n}.css`), 'utf8')).join('\n');
// home: 홈 화면 전용 스타일(글꼴은 site.css에 있으므로 빼고 묶음)
const cssBundles = { site: ['base', 'pages'], app: ['base', 'pages', 'app', 'preview'], admin: ['base', 'app', 'admin'], home: ['home', 'preview'] };
for (const [name, parts] of Object.entries(cssBundles)) {
  const r = await esbuild.transform(css(parts, name !== 'home'), { loader: 'css', minify: true });
  write(`assets/css/${name}.css`, r.code);
}

// 3) JS 묶기
const entryDir = path.join(root, 'src/js/entries');
const entries = fs.readdirSync(entryDir).filter((f) => f.endsWith('.js')).map((f) => path.join(entryDir, f));
await esbuild.build({
  entryPoints: entries, bundle: true, splitting: true, format: 'esm', minify: true, target: ['es2020', 'chrome90', 'safari15', 'firefox90'],
  outdir: path.join(out, 'assets/js'), chunkNames: 'chunks/[name]-[hash]', sourcemap: false, legalComments: 'none', logLevel: 'warning',
  define: { 'process.env.NODE_ENV': '"production"' },
});

// 4) 정적 자산
if (fs.existsSync(path.join(root, 'src/assets/img'))) copyDir(path.join(root, 'src/assets/img'), path.join(out, 'assets/img'));
for (const f of ['favicon.svg', 'favicon-32.png', 'apple-touch-icon.png', 'favicon.ico']) {
  const p = path.join(root, 'src/assets', f);
  if (fs.existsSync(p)) fs.copyFileSync(p, path.join(out, f));
}

// 5) 페이지 생성
const ctx = { site, T, root, assetVersion, guides: loadGuides(root) };
const pageDir = path.join(root, 'src/content/pages');
const pages = [];
for (const f of fs.readdirSync(pageDir).filter((f) => f.endsWith('.mjs')).sort()) {
  const mod = await import(pathToFileURL(path.join(pageDir, f)).href + `?v=${assetVersion}`);
  const list = await mod.default(ctx);
  for (const p of list) pages.push(p);
}
// 하위 경로(basePath)에 배포할 때 본문 속 절대 링크(/x/)에 경로를 붙인다
function withBase(html) {
  const b = site.basePath;
  if (!b) return html;
  return html.replace(/(\s(?:href|src|action|poster)=")(\/[^"]*)"/g, (m, a, u) => (u.startsWith('//') || u === b || u.startsWith(b + '/') ? m : `${a}${b}${u}"`));
}
// lastmod는 실제로 내용이 바뀐 날만 갱신한다: 가이드는 머리말(updated·date), 나머지는 tools/lastmod.json에 남긴 내용 지문으로 판단
const today = new Date(Date.now() + 9 * 3600e3).toISOString().slice(0, 10); // 한국 날짜
const indexable = pages.filter((p) => !p.noindex && p.path !== '/404.html');
const lmFile = path.join(root, 'tools/lastmod.json');
let lastmods = {};
try { lastmods = JSON.parse(fs.readFileSync(lmFile, 'utf8')); } catch { lastmods = {}; }
const fingerprint = (p) => crypto.createHash('sha1').update(JSON.stringify([p.title, p.description, p.h1, p.body, p.faq || null, p.schema || null, p.geo || ''])).digest('hex').slice(0, 16);
const nextLastmods = {};
for (const p of indexable) {
  if (p.modified || p.published) continue;
  const h = fingerprint(p);
  const prev = lastmods[p.path];
  nextLastmods[p.path] = prev && prev.h === h ? prev : { h, d: today };
}
// 배포용 로컬 빌드(docs/, 설정 주소 그대로)에서만 기록한다. CI·개발 서버 빌드는 읽기만 한다
if (!process.env.CI && !process.env.OUT_DIR && !process.env.SITE_URL && !process.env.BASE_PATH) fs.writeFileSync(lmFile, JSON.stringify(nextLastmods, null, 1) + '\n');
const lastmodOf = (p) => p.modified || p.published || (nextLastmods[p.path] || {}).d || today;
// 렌더링 전에 페이지마다 마지막 변경일을 붙여 둔다(구조화 데이터 dateModified와 본문 '기준일' 표기에 쓴다)
for (const p of indexable) p.lastmod = lastmodOf(p);
const seen = new Set();
for (const p of pages) {
  if (seen.has(p.path)) throw new Error('중복 경로: ' + p.path);
  seen.add(p.path);
  const html = withBase(T.layout(p));
  const rel = p.path === '/404.html' ? '404.html' : path.join(p.path.replace(/^\//, ''), 'index.html');
  write(rel, html);
}

// 6) 사이트맵·robots·RSS·llms.txt·매니페스트
write('sitemap.xml', `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${indexable.map((p) => `  <url><loc>${T.abs(p.path)}</loc><lastmod>${lastmodOf(p)}</lastmod><changefreq>${p.changefreq || 'weekly'}</changefreq><priority>${p.priority || (p.path === '/' ? '1.0' : '0.7')}</priority></url>`).join('\n')}\n</urlset>\n`);
// 검색·AI 답변 엔진은 모두 허용하되, 주문·결제·운영자 화면은 어느 봇에게도 열지 않는다
const BOTS = ['Yeti', 'Daumoa', 'Googlebot', 'Bingbot', 'GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'ClaudeBot', 'Claude-SearchBot', 'Claude-User', 'PerplexityBot', 'Perplexity-User', 'Google-Extended', 'Applebot', 'Applebot-Extended', 'DuckAssistBot', 'MistralAI-User', 'meta-externalagent', 'Amazonbot', 'CCBot'];
// 주문 조회(/orders/)는 바닥글에 링크가 있어 noindex로 검색에서 빼고, 크롤링은 막지 않는다(막으면 noindex를 읽지 못해 'robots.txt에 의해 차단됨'으로 남는다)
const PRIVATE = ['/admin/', '/checkout/'].map((p) => `Disallow: ${site.basePath}${p}`).join('\n');
// 다음 웹마스터도구 소유 확인: PIN 발급 때 받은 '#DaumWebMasterTool:...' 줄을 site.config.json verification.daum에 넣으면 robots.txt 맨 아래에 붙는다
const daumLine = String((site.verification || {}).daum || '').trim();
write('robots.txt', `User-agent: *\nAllow: /\n${PRIVATE}\n\n# 검색엔진·AI 검색·답변 엔진 허용\n${BOTS.map((b) => `User-agent: ${b}\nAllow: /\n${PRIVATE}\n`).join('\n')}\nSitemap: ${T.abs('/sitemap.xml')}\nSitemap: ${T.abs('/rss.xml')}\n${daumLine ? `\n${daumLine.startsWith('#') ? daumLine : `#${daumLine}`}\n` : ''}`);
const guides = ctx.guides.slice().sort((a, b) => (a.date < b.date ? 1 : -1));
const rssItems = guides.map((g) => `<item><title>${T.esc(g.title)}</title><link>${T.abs(`/guide/${g.slug}/`)}</link><guid>${T.abs(`/guide/${g.slug}/`)}</guid><pubDate>${new Date(g.date + 'T09:00:00+09:00').toUTCString()}</pubDate><description>${T.esc(g.description)}</description><category>${T.esc(g.category)}</category></item>`).join('');
write('rss.xml', `<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>논문AI 가이드</title><link>${T.abs('/guide/')}</link><description>논문 작성, 설문조사, 통계분석을 처음 하는 분을 위한 실전 가이드</description><language>ko</language>${rssItems}</channel></rss>\n`);
const llms = await import(pathToFileURL(path.join(root, 'tools/llms.mjs')).href);
write('llms.txt', llms.llmsTxt(ctx, pages));
write('llms-full.txt', llms.llmsFull(ctx, pages));
write('site.webmanifest', JSON.stringify({ name: '논문AI', short_name: '논문AI', start_url: site.basePath + '/', display: 'standalone', background_color: '#FFFFFF', theme_color: '#0F1B3D', icons: [{ src: site.basePath + '/assets/img/logo-192.png', sizes: '192x192', type: 'image/png' }, { src: site.basePath + '/assets/img/logo-512.png', sizes: '512x512', type: 'image/png' }] }));
write('.nojekyll', '');
write('assets/config.json', JSON.stringify({ apiUrl: site.apiUrl, version: assetVersion }));
if (site.indexNowKey) write(`${site.indexNowKey}.txt`, site.indexNowKey);
// 네이버 서치어드바이저 소유 확인(HTML 파일 방식): verification.naverFile에 확인 파일 이름(naver….html)을 넣으면 사이트 맨 위에 만든다. HTML 태그 방식은 verification.naver
const naverFile = String((site.verification || {}).naverFile || '').trim();
if (/^naver[0-9a-f]+\.html$/.test(naverFile)) write(naverFile, `naver-site-verification: ${naverFile}`);
console.log(`site: ${pages.length} pages, ${indexable.length} indexable, assets v=${assetVersion} → ${path.relative(root, out)}/`);
