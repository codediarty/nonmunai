// 검색엔진 색인 알림(IndexNow: 네이버·빙 등): node tools/indexnow.mjs https://nonmunai.kr [--all]
// 배포된 사이트의 sitemap.xml을 읽어, 최근에 내용이 바뀐 주소(lastmod가 어제 이후)만 보낸다. --all이면 전체를 보낸다.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const site = JSON.parse(fs.readFileSync(path.join(root, 'site.config.json'), 'utf8'));
const base = (process.argv[2] || site.siteUrl).replace(/^http:\/\/(?!localhost|127\.0\.0\.1)/, 'https://').replace(/\/+$/, '');
const host = new URL(base).host;
const key = site.indexNowKey;
if (!key) { console.log('indexNowKey 없음: 건너뜀'); process.exit(0); }
if (/github\.io$/.test(host)) { console.log('도메인 연결 전(github.io): 건너뜀'); process.exit(0); }

// 인증서 발급 직후에는 https가 늦게 열릴 수 있어 http로 한 번 더 읽는다
let xml = '';
for (const u of [`${base}/sitemap.xml`, `${base.replace(/^https:/, 'http:')}/sitemap.xml`]) {
  try { const r = await fetch(u, { headers: { 'Cache-Control': 'no-cache' } }); if (r.ok) { xml = await r.text(); break; } } catch (e) { console.log(`${u} 읽기 실패: ${e.message}`); }
}
const entries = [...xml.matchAll(/<url>\s*<loc>([^<]+)<\/loc>(?:\s*<lastmod>([^<]+)<\/lastmod>)?/g)].map((m) => ({ loc: m[1], lastmod: m[2] || '' })).filter((e) => e.loc.startsWith(base));
if (!entries.length) { console.log('sitemap에 주소가 없습니다'); process.exit(0); }
// 한국 날짜 기준 어제 이후에 바뀐 주소만(배포 직후 실행되므로 이번 배포에서 바뀐 주소가 들어간다)
const since = new Date(Date.now() + 9 * 3600e3 - 24 * 3600e3).toISOString().slice(0, 10);
const sendAll = process.argv.includes('--all') || process.env.INDEXNOW_ALL === '1';
const urlList = (sendAll ? entries : entries.filter((e) => !e.lastmod || e.lastmod >= since)).map((e) => e.loc);
if (!urlList.length) { console.log(`바뀐 주소 없음(기준 ${since} 이후): 건너뜀`); process.exit(0); }
console.log(`${sendAll ? '전체' : `${since} 이후 바뀐`} 주소 ${urlList.length}개 / sitemap ${entries.length}개`);
const keyLocation = `${base}/${key}.txt`;
const brief = async (r) => { try { return (await r.text()).replace(/\s+/g, ' ').trim().slice(0, 300); } catch { return ''; } };
const isRoot = (u) => u === `${base}/` || u === base;
for (const ep of ['https://api.indexnow.org/indexnow', 'https://searchadvisor.naver.com/indexnow']) {
  // 네이버 IndexNow는 홈 주소(https://도메인/)를 받지 않는다(422 Invalid urls, 2026-11-12 확인. 하위 주소는 200).
  // 홈은 서치어드바이저 사이트 등록과 사이트맵으로 수집되므로 네이버에는 홈을 빼고 보낸다
  const list = /naver\.com/.test(ep) ? urlList.filter((u) => !isRoot(u)) : urlList;
  // 홈이 바뀌었으면 네이버에는 끝 빗금 없는 주소(https://도메인)로 한 번만 따로 알려 본다(거절돼도 다른 주소 전송에는 영향 없음)
  if (/naver\.com/.test(ep) && urlList.some(isRoot)) {
    try {
      const g = await fetch(`${ep}?url=${encodeURIComponent(base)}&key=${key}&keyLocation=${encodeURIComponent(keyLocation)}`);
      console.log(`${ep} 홈(${base}) → ${g.status}${g.status === 200 || g.status === 202 ? '' : ` 응답: ${await brief(g)}`}`);
    } catch (e) { console.log(`${ep} 홈 실패: ${e.message}`); }
  }
  if (!list.length) { console.log(`${ep} → 건너뜀(바뀐 주소가 홈뿐)`); continue; }
  try {
    const r = await fetch(ep, { method: 'POST', headers: { 'Content-Type': 'application/json; charset=utf-8' }, body: JSON.stringify({ host, key, keyLocation, urlList: list }) });
    const ok = r.status === 200 || r.status === 202;
    console.log(`${ep} → ${r.status} (${list.length}개)${ok ? '' : ` 응답: ${await brief(r)}`}`);
    // 묶음 전송이 거절되면 주소마다 GET으로 한 번씩 다시 보내 어느 주소가 왜 막혔는지 남긴다(과다 전송을 피해 10개까지)
    if (!ok && r.status !== 429) {
      for (const u of list.slice(0, 10)) {
        try {
          const g = await fetch(`${ep}?url=${encodeURIComponent(u)}&key=${key}&keyLocation=${encodeURIComponent(keyLocation)}`);
          const gok = g.status === 200 || g.status === 202;
          console.log(`  GET ${u} → ${g.status}${gok ? '' : ` 응답: ${await brief(g)}`}`);
        } catch (e) { console.log(`  GET ${u} 실패: ${e.message}`); }
      }
    }
  } catch (e) { console.log(`${ep} 실패: ${e.message}`); }
}
