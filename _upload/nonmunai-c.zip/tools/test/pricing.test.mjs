// 가격 계산 단위 테스트 (TESTS.md 22, 23, 40 일부)
import assert from 'node:assert/strict';
import { DEFAULT_CATALOG, computeQuote, addBusinessDays, includesFor, listPriceFor, discountRate, pageLabel, EDIT_TYPES, editLevelOfCode, paperItemCode, QUOTE_AMOUNTS, isQuoteAmount } from '../../src/js/core/pricing.js';

export const tests = [];
const t = (name, fn) => tests.push({ name, fn });
const clone = (o) => JSON.parse(JSON.stringify(o));

t('논문 유형·작업 변경 시 가격 즉시 변경', () => {
  const base = { service: 'paper', paper: { typeId: 'master', task: 'full' } };
  assert.equal(computeQuote(DEFAULT_CATALOG, base).total, 99000);
  assert.equal(computeQuote(DEFAULT_CATALOG, { ...base, paper: { typeId: 'doctor', task: 'full' } }).total, 199000);
  assert.equal(computeQuote(DEFAULT_CATALOG, { ...base, paper: { typeId: 'master', task: 'edit' } }).total, 49000);
  assert.equal(computeQuote(DEFAULT_CATALOG, { ...base, paper: { typeId: 'master', task: 'feedback' } }).total, 99000);
  assert.equal(computeQuote(DEFAULT_CATALOG, { ...base, paper: { typeId: 'journal', task: 'full' } }).total, 99000);
});
t('추가 분량·옵션 가산', () => {
  const q = computeQuote(DEFAULT_CATALOG, { service: 'paper', paper: { typeId: 'master', task: 'full', pages: 85 }, addons: { priority: true, format: true, revisions: 1 } });
  // 99,000(80 Page) + 추가 5 Page(1블록×19,000) + 우선 처리 29,000 + 양식 19,000 + 추가 수정 19,000
  assert.equal(q.total, 99000 + 19000 + 29000 + 19000 + 19000);
  assert.equal(q.payableNow, true);
});
t('피드백 반영은 항목 수와 관계없이 한 가격', () => {
  for (const n of [null, 3, 17, 60]) {
    const q = computeQuote(DEFAULT_CATALOG, { service: 'paper', paper: { typeId: 'master', task: 'feedback', feedbackItems: n } });
    assert.equal(q.total, 99000, String(n));
    assert.equal(q.lines.length, 1, '추가 분량 줄 없음');
    assert.ok(!q.notes.some((x) => /undefined|기준 분량/.test(x)), q.notes.join(' / '));
  }
  const doc = computeQuote(DEFAULT_CATALOG, { service: 'paper', paper: { typeId: 'doctor', task: 'feedback', feedbackItems: 40, pages: 200 } });
  assert.equal(doc.total, 99000);
  assert.ok(doc.includes.includes('수정표 포함(의견·수정 내용·쪽)'));
});
t('설문 모집 의뢰는 견적형(결제 불가)', () => {
  const q = computeQuote(DEFAULT_CATALOG, { service: 'survey', survey: { mode: 'full', recruit: 'us' } });
  assert.equal(q.quoteRequired, true); assert.equal(q.payableNow, false);
  assert.ok(q.quoteReasons[0].includes('견적'));
});
t('통계: 데이터 유무·결과물에 따른 가격', () => {
  assert.equal(computeQuote(DEFAULT_CATALOG, { service: 'statistics', statistics: { hasData: true, output: 'table' } }).total, 49000);
  assert.equal(computeQuote(DEFAULT_CATALOG, { service: 'statistics', statistics: { hasData: true, output: 'interp', advanced: true } }).total, 69000 + 19000);
  assert.equal(computeQuote(DEFAULT_CATALOG, { service: 'statistics', statistics: { hasData: false, noDataPath: 'simulation' } }).total, 19000);
  const sem = computeQuote(DEFAULT_CATALOG, { service: 'statistics', statistics: { hasData: true, output: 'interp', sem: true } });
  assert.equal(sem.payableNow, false);
});
t('가격표 변경은 새 견적에만 반영', () => {
  const before = computeQuote(DEFAULT_CATALOG, { service: 'paper', paper: { typeId: 'master', task: 'full' } });
  const changed = clone(DEFAULT_CATALOG);
  changed.items.find((i) => i.code === 'P-MASTER-FULL').price = 179000;
  const after = computeQuote(changed, { service: 'paper', paper: { typeId: 'master', task: 'full' } });
  assert.equal(before.total, 99000); assert.equal(after.total, 179000);
});
t('영업일 계산(주말 제외)', () => {
  const d = addBusinessDays(new Date(2026, 10, 6), 1, []); // 2026-11-06 금 → 11-09 월
  assert.equal(d.getDate(), 9);
});
t('심사 발표 PPT·영문 논문 작성·논문 첨삭 옵션', () => {
  // 석사 80 Page + 영문(80 Page → 10 Page 단위 8개) + PPT
  const q = computeQuote(DEFAULT_CATALOG, { service: 'paper', paper: { typeId: 'master', task: 'full', pages: 80 }, addons: { ppt: true, english: true } });
  const en = q.lines.find((l) => l.code === 'A-ENGLISH');
  assert.equal(en.qty, 8);
  assert.equal(en.amount, 8 * 29000);
  assert.ok(q.lines.some((l) => l.code === 'A-PPT' && l.amount === 49000));
  assert.equal(q.total, 99000 + 8 * 29000 + 49000);
  // 영문 작성은 전체 구성·초고 완성에만, 논문 첨삭은 피드백 반영·통계·설문에만 붙는다
  const fb = computeQuote(DEFAULT_CATALOG, { service: 'paper', paper: { typeId: 'doctor', task: 'feedback' }, addons: { english: true, editing: true } });
  assert.ok(!fb.lines.some((l) => l.code === 'A-ENGLISH'));
  assert.ok(fb.lines.some((l) => l.code === 'P-DOCTOR-EDIT' && l.amount === 69000));
  const full = computeQuote(DEFAULT_CATALOG, { service: 'paper', paper: { typeId: 'master', task: 'full' }, addons: { editing: true } });
  assert.ok(!full.lines.some((l) => /-EDIT$/.test(l.code)));
  const st = computeQuote(DEFAULT_CATALOG, { service: 'statistics', statistics: { hasData: true, output: 'interp' }, addons: { editing: true, editingType: 'journal', ppt: true } });
  assert.ok(st.lines.some((l) => l.code === 'P-JOURNAL-EDIT'));
  assert.equal(st.total, 69000 + 39000 + 49000);
  const sv = computeQuote(DEFAULT_CATALOG, { service: 'survey', survey: { mode: 'full', recruit: 'none' }, addons: { editing: true, editingType: 'nope' } });
  assert.ok(sv.lines.some((l) => l.code === 'P-MASTER-EDIT'), '알 수 없는 유형은 석사 기준');
});
t('논문 완성 대표 요금(소논문 15·학사 30·학술지 20·석사 80·박사 130 Page)', () => {
  const q = (typeId, pages) => computeQuote(DEFAULT_CATALOG, { service: 'paper', paper: { typeId, task: 'full', pages } });
  assert.equal(q('short', 15).total, 49000);
  assert.equal(q('short', 15).days, 2);
  assert.equal(q('short', 20).total, 49000 + 9000);
  assert.equal(q('short', 25).total, 49000 + 9000 * 2);
  assert.ok(q('short', 20).lines.some((l) => l.code === 'P-SHORT-FULL-X' && l.qty === 1));
  assert.equal(q('bachelor', 30).total, 59000);
  assert.equal(q('journal', 20).total, 99000);
  assert.equal(q('master', 80).total, 99000);
  assert.equal(q('master', 80).lines.length, 1, '석사 80 Page는 상품 하나로 결제');
  assert.equal(q('doctor', 130).total, 199000);
  assert.equal(q('doctor', 130).lines.length, 1, '박사 130 Page는 상품 하나로 결제');
  // 소논문은 전체 구성·초고 완성만 있음(첨삭·피드백 상품 없음)
  assert.ok(!DEFAULT_CATALOG.items.some((i) => /^P-SHORT-(EDIT|FB|PROP)$/.test(i.code)));
});

t('포함 항목의 분량은 주문한 Page로 표시', () => {
  const q = computeQuote(DEFAULT_CATALOG, { service: 'paper', paper: { typeId: 'master', task: 'full', pages: 80 } });
  const inc = includesFor(q.includes, 80);
  assert.ok(inc.includes('서론부터 결론까지 장별 본문 80 Page'), inc.join(' / '));
  assert.ok(includesFor(q.includes, 90).includes('서론부터 결론까지 장별 본문 90 Page'));
  assert.ok(!inc.some((x) => /쪽/.test(x)));
  // 분량을 모르면 원래 문구 그대로, 항목 수 기준(피드백)은 건드리지 않음
  assert.deepEqual(includesFor(q.includes, 0), q.includes);
  const fb = computeQuote(DEFAULT_CATALOG, { service: 'paper', paper: { typeId: 'master', task: 'feedback', feedbackItems: 10 } });
  assert.deepEqual(includesFor(fb.includes, 45), fb.includes);
  const ed = computeQuote(DEFAULT_CATALOG, { service: 'paper', paper: { typeId: 'bachelor', task: 'edit', pages: 45 } });
  assert.ok(includesFor(ed.includes, 45).includes('원고 문장 교정(45 Page)'));
});

t('논문 첨삭 세 단계: 기본 교정·심화 첨삭·완성도 보완(2026-11-26)', () => {
  const q = (typeId, level, pages) => computeQuote(DEFAULT_CATALOG, { service: 'paper', paper: { typeId, task: 'edit', pages, editLevel: level } });
  // 학사 20 Page: 기본 29,000원, 심화 10만 원, 완성도 30만 원(운영자가 직접 정한 금액을 기준으로)
  assert.equal(q('bachelor', 'basic', 20).total, 29000);
  assert.equal(q('bachelor', undefined, 20).total, 29000, '단계를 안 고르면 기본 교정');
  assert.equal(q('bachelor', 'deep', 20).total, 100000);
  assert.equal(q('bachelor', 'complete', 20).total, 300000);
  assert.equal(q('bachelor', 'complete', 20).mainCode, 'P-BACHELOR-EDIT3');
  assert.equal(q('bachelor', 'complete', 30).total, 300000);
  assert.equal(q('bachelor', 'complete', 31).total, 400000, '기준 30 Page를 넘으면 10 Page마다 10만 원');
  assert.equal(q('bachelor', 'deep', 41).total, 200000);
  assert.equal(q('master', 'deep', 80).total, 200000);
  assert.equal(q('master', 'complete', 120).total, 600000);
  assert.equal(q('doctor', 'complete', 150).total, 800000);
  // 심화·완성도 보완은 분량이 늘어도 늘 10만 원 단위(맞춤 견적 결제 상품 하나로 결제)
  for (const t of EDIT_TYPES) for (const level of ['deep', 'complete']) for (const pages of [1, 15, 29, 30, 44, 80, 99, 150, 151]) {
    const r = q(t, level, pages);
    assert.equal(r.total % 100000, 0, `${t} ${level} ${pages}`);
    assert.equal(r.quoteRequired, false);
    assert.ok(r.days >= q(t, 'basic', pages).days, `${t} ${level} 납기`);
  }
  // 단계가 높을수록 포함 범위가 넓고 금액도 높다
  for (const t of EDIT_TYPES) {
    const [a, b, c] = ['basic', 'deep', 'complete'].map((l) => q(t, l, 20));
    assert.ok(a.total < b.total && b.total < c.total, t);
    assert.ok(b.includes.some((x) => /AI 문체/.test(x)) && !a.includes.some((x) => /AI 문체/.test(x)), t);
    assert.ok(c.includes.some((x) => /보완 집필/.test(x)) && !b.includes.some((x) => /보완 집필/.test(x)), t);
    assert.ok(c.includes.includes('수정 1회'));
  }
  assert.equal(editLevelOfCode('P-MASTER-EDIT3').id, 'complete');
  assert.equal(editLevelOfCode('P-MASTER-EDIT').id, 'basic');
  assert.equal(editLevelOfCode('P-MASTER-FULL'), null);
  assert.equal(paperItemCode('master', 'edit', 'deep'), 'P-MASTER-EDIT2');
  assert.equal(paperItemCode('master', 'feedback', 'deep'), 'P-MASTER-FB');
  // 운영 가격표에 아직 단계 상품이 없으면 기본 금액으로 결제받지 않고 확인 후 안내(견적형)
  const old = { ...DEFAULT_CATALOG, items: DEFAULT_CATALOG.items.filter((i) => !/-EDIT[23]$/.test(i.code)) };
  const r = computeQuote(old, { service: 'paper', paper: { typeId: 'bachelor', task: 'edit', pages: 20, editLevel: 'complete' } });
  assert.equal(r.quoteRequired, true);
  assert.equal(r.payableNow, false);
  assert.match(r.quoteReasons[0], /완성도 보완/);
});

t('맞춤 견적 결제 금액은 10만~100만 원, 10만 원 단위', () => {
  assert.deepEqual(QUOTE_AMOUNTS, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((n) => n * 100000));
  assert.ok(isQuoteAmount(300000) && isQuoteAmount('1000000'));
  assert.ok(!isQuoteAmount(29000) && !isQuoteAmount(1100000) && !isQuoteAmount(250000) && !isQuoteAmount(0));
});

t('정가와 할인 행사 할인율', () => {
  // 정가는 판매가의 두 배보다 높게 잡고, 할인율은 55~60%(반값으로 딱 떨어지지 않게)
  for (const [code, price, list, rate] of [['P-SHORT-FULL', 49000, 109000, 55], ['P-BACHELOR-FULL', 59000, 139000, 57], ['P-JOURNAL-FULL', 99000, 229000, 56], ['P-MASTER-FULL', 99000, 249000, 60], ['P-DOCTOR-FULL', 199000, 459000, 56], ['P-BACHELOR-PROP', 29000, 69000, 57], ['P-MASTER-PROP', 69000, 159000, 56], ['P-DOCTOR-PROP', 99000, 229000, 56]]) {
    assert.equal(listPriceFor(code, price), list, code);
    assert.equal(discountRate(list, price), rate, code);
  }
  // 정가가 없거나 판매가보다 낮으면 표시하지 않음
  assert.equal(listPriceFor('T-BASIC', 49000), 0);
  assert.equal(listPriceFor('P-SHORT-FULL', 120000), 0);
  assert.equal(discountRate(0, 99000), 0);
  assert.equal(pageLabel(80), '80 Page');
});
