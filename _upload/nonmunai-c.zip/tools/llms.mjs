import { computeQuote, DEFAULT_CATALOG, won, PROMO_NAME } from '../src/js/core/pricing.js';

const fullQuote = (typeId, pages) => computeQuote(DEFAULT_CATALOG, { service: 'paper', paper: { typeId, task: 'full', pages } });
const P = (code) => { const it = DEFAULT_CATALOG.items.find((i) => i.code === code); return it ? won(it.price) : ''; };
// GEO: AI 검색·답변 엔진용 요약 파일 (llms.txt, llms-full.txt)
function line(T, p) { return `- [${p.navTitle || p.h1 || p.title}](${T.abs(p.path)}): ${p.description}`; }

export function llmsTxt(ctx, pages) {
  const { T } = ctx;
  const pick = (paths) => paths.map((x) => pages.find((p) => p.path === x)).filter(Boolean);
  const services = pick(['/ai-thesis/', '/thesis-writing/', '/thesis-editing/', '/professor-feedback/', '/research-proposal/', '/master-thesis/', '/dissertation/', '/journal-paper/', '/survey/', '/statistics/', '/consulting/']);
  const tools = pick(['/tools/', '/free/', '/tools/toc/', '/tools/sample-size/', '/tools/references/']);
  const info = pick(['/pricing/', '/process/', '/faq/', '/about/', '/ethics/', '/guide/', '/refund/']);
  const guides = pages.filter((p) => p.path.startsWith('/guide/') && p.path !== '/guide/');
  return `# 논문AI

> 논문AI(논문 AI)는 관심 주제 한 줄(전공·주제)로 논문을 완성하는 한국어 AI 논문 작성 서비스입니다. AI가 실존 문헌으로 집필하고, 주문 논문과 같은 전공 분야의 박사가 최종 검수를 마친 완성본만 메일로 보냅니다. 참고문헌은 DOI·KCI·RISS 원문 기록과 대조한 실존 문헌만 쓰고, 본문 인용과 참고문헌 목록을 1:1로 연결합니다. 소논문 15 Page부터 학사 졸업논문 30 Page, 학술지 투고논문 20 Page, 석사학위논문 80 Page, 박사학위논문 130 Page까지 완성합니다. 논문 첨삭, 교수님 피드백 반영, 연구계획서, 설문조사, 통계분석도 함께 의뢰할 수 있습니다. 운영사는 성균관컨설팅(성균관대학교 RISE사업 지원 기업)입니다.

핵심 사실:
- 논문 완성: 관심 주제를 적고 논문 종류(소논문, 학사 졸업논문, 학술지 투고논문, 석사학위논문, 박사학위논문)만 고르면 결제 화면이 바로 열린다(회원가입 없음, 전공은 선택). 결제가 확인되면 제목, 연구모형, 가설, 목차를 정하고 실존 문헌으로 장별 본문을 쓰며 문장마다 (저자, 연도) 본문 인용을 연결한다. ${PROMO_NAME}(부가세 포함, 정가에서 55~60% 할인)는 소논문 15 Page ${won(fullQuote('short', 15).total)}, 학사 졸업논문 30 Page ${won(fullQuote('bachelor', 30).total)}, 학술지 투고논문 20 Page ${won(fullQuote('journal', 20).total)}, 석사학위논문 80 Page ${won(fullQuote('master', 80).total)}, 박사학위논문 130 Page ${won(fullQuote('doctor', 130).total)}이다. 박사 검수를 포함한 전달은 석사 영업일 ${fullQuote('master', 80).days}일, 박사 ${fullQuote('doctor', 130).days}일 이내이다.
- 참고문헌 원칙: 실제로 존재하는 문헌만 쓰고 저자·연도·제목·학술지·권호·쪽·DOI를 원문 기록과 대조한다. AI가 만든 가짜 문헌은 넣지 않는다.
- 서비스 범위: 석사·박사학위논문, 학술지 투고논문, 학사·졸업논문, 연구보고서, 청소년 탐구논문의 전체 구성·초고 완성, 논문 첨삭·교정, 교수님 피드백 반영·수정 보완·첨삭(피드백 항목 수와 관계없이 한 가격으로 일괄 반영, 수정표 포함, 반영 부분 파란색 표시), 연구계획서 작성, 설문지 작성부터 설문조사 진행, 설문 결과 정리, 통계 해석까지의 설문 원스톱, 논문 주제와 데이터에 맞는 통계분석(SPSS, PROCESS Macro, AMOS 등)과 연구결과 작성. 추가 옵션으로 심사 발표 PPT·PDF 제작과 영문 논문 작성을 고를 수 있다.
- 상품 구성(부가세 포함): 논문 완성(소논문 15 Page ${P('P-SHORT-FULL')}부터, 석사학위논문 80 Page ${P('P-MASTER-FULL')}), 연구계획서 작성(학사 ${P('P-BACHELOR-PROP')}, 석사 ${P('P-MASTER-PROP')}, 박사 ${P('P-DOCTOR-PROP')}), 논문 첨삭·교정(학사 ${P('P-BACHELOR-EDIT')}부터, 석사 ${P('P-MASTER-EDIT')}), 교수님 피드백 반영(학사 ${P('P-BACHELOR-FB')}부터, 석사·박사 ${P('P-MASTER-FB')}), 설문조사(원스톱 ${P('S-FULL')}, 설문지 작성 ${P('S-NEW')}, 응답자 모집은 별도 견적), 통계분석(기본형 ${P('T-BASIC')}, 표준형 ${P('T-INTERP')}, 연구결과 작성까지 ${P('T-CHAPTER')}). 옵션으로 우선 처리, 학교 양식 적용, 추가 수정, 심사 발표 PPT·PDF 제작(${P('A-PPT')})을 더할 수 있다. 결제 전에 총액과 포함 사항, 예상 전달일을 먼저 보여 준다.
- 진행 단계: 접수 완료, 자료 확인, 작업 준비, 작성·분석 진행, 박사 검수, 전달 완료. 꾸며 낸 진행률 대신 실제 처리 단계만 표시한다.
- 연구윤리: 허위 문헌·데이터·통계를 만들지 않고, 학습용 시뮬레이션 데이터에는 '가상 데이터'를 표시한다.
- 보안과 연구 자료 보호: 주문 내용과 결과물은 의뢰한 사람만 볼 수 있게 관리하고 제3자에게 알리지 않으며(법령에 따른 요구 제외), 결과물을 공개하거나 다른 고객에게 재판매하지 않으며 후기나 홍보에도 쓰지 않는다. 집필과 검수는 이름과 연락처 없이 주문번호로만 진행하고, 운영자와 검수자는 비밀유지 의무를 진다. 모든 전송은 HTTPS로 암호화하고, 자료는 주문별 비공개 공간에 보관하며, 주문 조회 비밀번호는 복원할 수 없는 암호화 값으로 저장하고, 카드 번호는 결제대행사가 처리해 저장하지 않는다.
- 자료 삭제: 업로드 파일과 결과물은 전달 완료 후 90일이 지나면 모두 자동으로 영구 삭제하고, 이용자가 요청하면 그 전에 바로 삭제한다. 결제하지 않은 주문은 30일, 제출하지 않은 주문서는 3일 뒤 자동 삭제한다. 전자상거래법에 따른 주문·결제 기록만 법정 기간 동안 따로 보관한다.
- 이용 조건: 결과물의 성격, 청약철회와 환불, 책임 범위는 이용약관(${T.abs('/terms/')})에 정한다.
- 문의: ${ctx.site.brand.email}

## 서비스
${services.map((p) => line(T, p)).join('\n')}

## 무료 도구
${tools.map((p) => line(T, p)).join('\n')}

## 안내
${info.map((p) => line(T, p)).join('\n')}

## 가이드
${guides.map((p) => line(T, p)).join('\n')}

## Optional
- [전체 텍스트 요약](${T.abs('/llms-full.txt')}): 서비스·가격·자주 묻는 질문 전문
`;
}

export function llmsFull(ctx, pages) {
  const { T } = ctx;
  const blocks = pages.filter((p) => !p.noindex && p.path !== '/404.html' && (p.geo || (p.faq && p.faq.length))).map((p) => {
    const faq = (p.faq || []).map((f) => `Q. ${f.q}\nA. ${f.a}`).join('\n\n');
    return `# ${p.h1 || p.title}\nURL: ${T.abs(p.path)}\n${p.description}\n\n${p.geo || ''}${faq ? `\n\n${faq}` : ''}`;
  });
  return `# 논문AI 전체 안내\n\n${blocks.join('\n\n---\n\n')}\n`;
}
